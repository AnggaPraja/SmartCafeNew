<?php
header("Location: web/index.php");
